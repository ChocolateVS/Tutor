﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _103_PracTest2_Smack
{
    public partial class Form1 : Form
    {
        //Name:
        //ID:

        //The number of squares in each row
        const int NUM_COLUMNS = 10;
        //The minimum number of rows to draw
        const int MIN_ROWS = 5;
        //The maximum number of rows to draw
        const int MAX_ROWS = 10;


        public Form1()
        {
            InitializeComponent();
        }
    }
}
